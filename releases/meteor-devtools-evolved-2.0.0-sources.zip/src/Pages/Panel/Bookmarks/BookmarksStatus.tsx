import { observer } from 'mobx-react-lite'
import React, { FormEvent, FunctionComponent, useCallback } from 'react'

import { usePanelStore } from '@/Stores/PanelStore'
import { StatusBar } from '@/Components/StatusBar'
import { DDPFilterMenu } from '@/Pages/Panel/DDP/DDPFilterMenu'
import { TextInput } from '@/Components/TextInput'
import { PopoverButton } from '@/Components/PopoverButton'
import { Field } from '@/Components/Field'
import { exists } from '@/Utils'

export const BookmarksStatus: FunctionComponent = observer(() => {
  const store = usePanelStore()
  const { bookmarkStore, settingStore } = store

  const activeFilters = store.settingStore.activeFilters
  const setFilter = useCallback(
    (type, isEnabled) => settingStore.setFilter(type, isEnabled),
    [settingStore],
  )
  const collectionLength = bookmarkStore.collection.length
  const { pagination } = bookmarkStore

  return (
    <StatusBar>
      <div className='left-group'>
        <PopoverButton
          icon='filter'
          height={28}
          content={
            <DDPFilterMenu
              setFilter={setFilter}
              activeFilters={activeFilters}
            />
          }
          placement='right-start'
        >
          Filter
        </PopoverButton>

        <TextInput
          icon='search'
          placeholder='Search...'
          onChange={(event: FormEvent<HTMLInputElement>) =>
            pagination.setSearch(event.currentTarget.value)
          }
        />

        <Field icon='eye-open'>{pagination.length}</Field>
      </div>

      <div className='right-group'>
        {exists(collectionLength) && (
          <Field intent='warning' icon='inbox'>
            {collectionLength}
          </Field>
        )}
      </div>
    </StatusBar>
  )
})
