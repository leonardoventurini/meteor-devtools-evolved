import { Position, Spinner, Tag, Tooltip } from '@blueprintjs/core'
import { isNumber } from 'lodash'
import { observer } from 'mobx-react-lite'
import React, { FormEvent, FunctionComponent, useCallback } from 'react'
import { usePanelStore } from '@/Stores/PanelStore'
import { StatusBar } from '@/Components/StatusBar'
import { DDPFilterMenu } from '@/Pages/Panel/DDP/DDPFilterMenu'
import { TextInput } from '@/Components/TextInput'
import { PopoverButton } from '@/Components/PopoverButton'
import { Button } from '@/Components/Button'
import prettyBytes from 'pretty-bytes'
import { Field } from '@/Components/Field'
import { StringUtils } from '@/Utils/StringUtils'
import { showToast } from '@/AppToaster'

export const DDPStatus: FunctionComponent = observer(() => {
  const store = usePanelStore()
  const { ddpStore, settingStore } = store

  const activeFilters = settingStore.activeFilters
  const setFilter = useCallback(
    (type, isEnabled) => settingStore.setFilter(type, isEnabled),
    [settingStore],
  )
  const collectionLength = ddpStore.connectionLogs.length
  const {
    connectionInboundBytes,
    connectionOutboundBytes,
    isLoading,
    pagination,
  } = ddpStore

  return (
    <StatusBar>
      <div className='left-group'>
        <PopoverButton
          icon='filter'
          height={28}
          content={
            <DDPFilterMenu
              setFilter={setFilter}
              activeFilters={activeFilters}
            />
          }
          placement='right-start'
        >
          Filter
        </PopoverButton>

        <TextInput
          icon='search'
          placeholder='Search...'
          onChange={(event: FormEvent<HTMLInputElement>) =>
            pagination.setSearch(event.currentTarget.value)
          }
        />

        <Field icon='eye-open'>{pagination.length}</Field>
      </div>

      <div className='right-group'>
        {isLoading && (
          <Field>
            <Spinner size={12} intent='warning' />
          </Field>
        )}

        {store.gitCommitHash ? (
          <Tooltip
            content='Git Commit Hash'
            hoverOpenDelay={800}
            position='top'
          >
            <Tag
              minimal
              interactive
              onClick={() => {
                StringUtils.toClipboard(store.gitCommitHash as string)
                void showToast({
                  icon: 'tick',
                  message: 'Copied to Clipboard',
                  intent: 'success',
                  timeout: 1000,
                })
              }}
              style={{ marginRight: 4 }}
            >
              {store.gitCommitHash.slice(0, 8)}
            </Tag>
          </Tooltip>
        ) : null}

        {!!connectionInboundBytes && (
          <Field icon='cloud-download'>
            {prettyBytes(connectionInboundBytes)}
          </Field>
        )}

        {!!connectionOutboundBytes && (
          <Field icon='cloud-upload'>
            {prettyBytes(connectionOutboundBytes)}
          </Field>
        )}

        {isNumber(collectionLength) && (
          <Button
            intent='warning'
            onClick={() => ddpStore.clearLogs()}
            icon='inbox'
          >
            {collectionLength}
          </Button>
        )}
      </div>
    </StatusBar>
  )
})
